
$(document).ready(function() { 
    $('.slider').slick({
        infinite: false,
        dots: true
    }); 
});

